import React, { useState, useEffect } from 'react';
import { VocabularyData, SavedCard, ExampleSentence } from '../types';
import { fetchTextToSpeech } from '../services/dictionaryService';

interface FlipCardProps {
  data: VocabularyData | SavedCard;
  onSave?: () => void;
  isSaved?: boolean;
  onToggleFavorite?: (id: string) => void;
}

export const FlipCard: React.FC<FlipCardProps> = ({ data, onSave, isSaved = false, onToggleFavorite }) => {
  const [isFlipped, setIsFlipped] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  // Reset state when data changes
  useEffect(() => {
    setIsFlipped(false);
    setIsPlayingAudio(false);
  }, [data.kanji]);

  const handleCardClick = (e: React.MouseEvent) => {
    // Prevent flip if clicking buttons inside the card
    if ((e.target as HTMLElement).closest('button') || (e.target as HTMLElement).closest('input') || (e.target as HTMLElement).closest('select')) {
      return;
    }
    setIsFlipped(!isFlipped);
  };

  const handleSaveClick = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent card flip
    if (onSave) {
      onSave();
    }
  };

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onToggleFavorite && 'id' in data) {
      onToggleFavorite((data as SavedCard).id);
    }
  };

  // --- Audio Logic ---
  const handlePlayAudio = async (sentence: ExampleSentence) => {
    if (isPlayingAudio) return;

    // Use preloaded audio if available, otherwise fetch it
    let base64Audio = sentence.audio;

    setIsPlayingAudio(true);

    try {
      if (!base64Audio) {
         // Fallback: Fetch audio on demand if not preloaded (e.g. for Saved Cards or if preload failed)
         const cleanText = sentence.japanese.replace(/<[^>]*>/g, '');
         base64Audio = await fetchTextToSpeech(cleanText);
      }

      if (base64Audio) {
        // Decode and Play
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        
        // Convert Base64 to Uint8Array
        const binaryString = atob(base64Audio);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }

        // Decode raw PCM (Int16) to AudioBuffer (Float32)
        const dataInt16 = new Int16Array(bytes.buffer);
        const buffer = audioContext.createBuffer(1, dataInt16.length, 24000);
        const channelData = buffer.getChannelData(0);
        
        for (let i = 0; i < dataInt16.length; i++) {
          channelData[i] = dataInt16[i] / 32768.0;
        }

        const source = audioContext.createBufferSource();
        source.buffer = buffer;
        source.connect(audioContext.destination);
        
        source.onended = () => {
          setIsPlayingAudio(false);
          audioContext.close();
        };

        source.start();
      } else {
        setIsPlayingAudio(false);
      }
    } catch (error) {
      console.error("Audio playback error", error);
      setIsPlayingAudio(false);
    }
  };


  // Helper to highlight text wrapped in <b> tags
  const renderHighlightedSentence = (text: string) => {
    // Split by tags, keeping the tags in the result for identification
    const parts = text.split(/(<b>.*?<\/b>)/g);
    
    return parts.map((part, index) => {
      if (part.startsWith('<b>') && part.endsWith('</b>')) {
        const content = part.replace(/<\/?b>/g, '');
        return (
          <span key={index} className="text-yellow-300 font-bold mx-0.5 border-b-2 border-yellow-300/30">
            {content}
          </span>
        );
      }
      return <span key={index}>{part}</span>;
    });
  };

  const isFavorite = 'isFavorite' in data ? !!data.isFavorite : false;

  // Always use the first general sentence
  const displaySentence = data.sentences[0];

  const StarIcon = ({ filled, className = "" }: { filled: boolean, className?: string }) => (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      className={`h-6 w-6 sm:h-7 sm:w-7 transition-all duration-200 ${filled ? 'fill-yellow-400 text-yellow-400' : 'fill-transparent text-gray-300 hover:text-yellow-400'} ${className}`}
      viewBox="0 0 24 24" 
      stroke="currentColor" 
      strokeWidth={filled ? 0 : 2}
    >
      <path strokeLinecap="round" strokeLinejoin="round" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
    </svg>
  );

  return (
    <div className="relative w-full max-w-[300px] sm:max-w-sm h-[360px] sm:h-[420px] mx-auto perspective-1000 group cursor-pointer z-10" onClick={handleCardClick}>
      <div
        className={`relative w-full h-full duration-700 transform-style-3d shadow-xl rounded-2xl transition-transform ${
          isFlipped ? 'rotate-y-180' : ''
        }`}
      >
        {/* FRONT SIDE (Kana/Romaji Only) */}
        <div className="absolute w-full h-full backface-hidden bg-white rounded-2xl p-4 sm:p-6 flex flex-col justify-between border-2 border-indigo-50">
          
          {/* Favorite Button (Front) */}
          {isSaved && onToggleFavorite && (
            <button 
              onClick={handleFavoriteClick}
              className="absolute top-3 right-3 sm:top-4 sm:right-4 z-20 p-1 rounded-full hover:bg-gray-50 transition-colors"
              title={isFavorite ? "Remove from favorites" : "Add to favorites"}
            >
              <StarIcon filled={isFavorite} />
            </button>
          )}

          <div className="flex-1 flex flex-col items-center justify-center text-center">
            
            {/* Readings - Emphasized */}
            <div className="flex flex-col items-center justify-center flex-1">
              <span className="text-5xl sm:text-6xl font-jp text-indigo-900 font-bold mb-4">{data.kana}</span>
              <span className="text-lg text-gray-400 font-mono tracking-wide bg-gray-50 px-3 py-1 rounded-full">{data.romaji}</span>
            </div>

            <div className="w-full flex flex-col items-center">
                <div className="w-10 sm:w-12 h-1 bg-gray-200 rounded-full mb-4"></div>
                
                <p className="text-gray-400 text-xs sm:text-sm italic">
                "Click to reveal Kanji & Meaning"
                </p>
            </div>
          </div>
        </div>

        {/* BACK SIDE (Kanji Emphasis + Meaning) */}
        <div className="absolute w-full h-full backface-hidden rotate-y-180 bg-indigo-900 text-white rounded-2xl p-3 sm:p-5 flex flex-col border-2 border-indigo-800">
          
          {/* Favorite Button (Back) */}
           {isSaved && onToggleFavorite && (
            <button 
              onClick={handleFavoriteClick}
              className="absolute top-3 right-3 sm:top-4 sm:right-4 z-20 p-1 rounded-full hover:bg-indigo-800 transition-colors"
            >
              <StarIcon filled={isFavorite} className={!isFavorite ? "text-indigo-400 hover:text-yellow-400" : ""} />
            </button>
          )}

           {/* Top Section: Word (Kanji + Meaning) */}
           <div className="text-center pt-2 mb-2 sm:mb-4 flex-1 flex flex-col justify-center">
             <div className="flex items-center justify-center mb-1">
                <h2 className="text-5xl sm:text-6xl font-jp font-bold leading-tight tracking-wider">{data.kanji}</h2>
             </div>
             {/* English Meaning Moved to Back */}
             <p className="text-indigo-200 text-lg sm:text-xl font-medium px-2 leading-tight">
                {data.english[0]}
             </p>
          </div>

          {/* Middle Section: Sentence */}
          <div className="bg-indigo-800/50 p-2 sm:p-3 rounded-lg flex-1 flex flex-col justify-center min-h-0">
            <div className="flex justify-between items-center mb-1">
              <p className="text-[10px] sm:text-xs text-indigo-300 uppercase tracking-wide">
                Example
              </p>
            </div>
            
            <div className="flex items-start gap-2">
              <p 
                className="text-sm sm:text-base font-jp mb-1 leading-relaxed overflow-y-auto max-h-[80px] sm:max-h-none flex-1 [&::-webkit-scrollbar]:hidden"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
              >
                {renderHighlightedSentence(displaySentence.japanese)}
              </p>
              
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  handlePlayAudio(displaySentence);
                }}
                disabled={isPlayingAudio}
                className={`mt-0.5 p-1.5 rounded-full transition-all ${isPlayingAudio ? 'bg-indigo-700 text-indigo-400 animate-pulse cursor-wait' : 'bg-indigo-700 text-white hover:bg-indigo-600 hover:scale-110'}`}
                title="Listen to sentence"
              >
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 sm:h-5 sm:w-5" viewBox="0 0 20 20" fill="currentColor">
                   <path fillRule="evenodd" d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.707.707L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.707-3.707a1 1 0 011.09-.217zM14.657 2.929a1 1 0 011.414 0A9.972 9.972 0 0119 10a9.972 9.972 0 01-2.929 7.071 1 1 0 01-1.414-1.414A7.971 7.971 0 0017 10c0-2.21-.894-4.208-2.343-5.657a1 1 0 010-1.414zm-2.829 2.828a1 1 0 011.415 0A5.983 5.983 0 0115 10a5.984 5.984 0 01-1.757 4.243 1 1 0 01-1.415-1.415A3.984 3.984 0 0013 10a3.983 3.983 0 00-1.172-2.828 1 1 0 010-1.414z" clipRule="evenodd" />
                 </svg>
              </button>
            </div>
            
            <p className="text-[10px] sm:text-xs text-gray-300 leading-tight">{displaySentence.english}</p>
          </div>

          {/* Bottom Section: Action */}
          <div className="mt-2 sm:mt-4 flex justify-center pb-1 sm:pb-2">
            {!isSaved && onSave && (
              <button
                onClick={handleSaveClick}
                className="bg-japan-red hover:bg-red-700 text-white font-bold py-1.5 sm:py-2 px-4 sm:px-6 text-sm sm:text-base rounded-full shadow-lg transform transition hover:scale-105 flex items-center gap-2"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 sm:h-5 sm:w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M5 4a2 2 0 012-2h6a2 2 0 012 2v14l-5-2.5L5 18V4z" />
                </svg>
                Collect
              </button>
            )}
             {isSaved && (
               <div className="text-green-400 text-sm font-bold flex items-center gap-1">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 sm:h-5 sm:w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  In Collection
               </div>
             )}
          </div>
        </div>
      </div>
    </div>
  );
};