import React, { useMemo, useState } from 'react';
import { SavedCard } from '../types';
import { FlipCard } from './FlipCard';

interface CollectionGridProps {
  cards: SavedCard[];
  onToggleFavorite: (id: string) => void;
}

export const CollectionGrid: React.FC<CollectionGridProps> = ({ cards, onToggleFavorite }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);

  // Filter and Sort cards
  const displayedCards = useMemo(() => {
    let result = [...cards];

    // 1. Sort Alphabetically by English meaning
    result.sort((a, b) => {
      const textA = a.english[0].toLowerCase();
      const textB = b.english[0].toLowerCase();
      return textA.localeCompare(textB);
    });

    // 2. Filter by Search Term
    if (searchTerm.trim()) {
      const lowerTerm = searchTerm.toLowerCase();
      result = result.filter(card => 
        card.english.some(e => e.toLowerCase().includes(lowerTerm)) ||
        card.kanji.includes(lowerTerm) ||
        card.romaji.toLowerCase().includes(lowerTerm) ||
        card.kana.includes(lowerTerm)
      );
    }

    // 3. Filter by Favorites
    if (showFavoritesOnly) {
      result = result.filter(card => card.isFavorite);
    }

    return result;
  }, [cards, searchTerm, showFavoritesOnly]);

  if (cards.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-gray-400">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mb-4 opacity-50" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
        </svg>
        <p className="text-xl font-medium">Your deck is empty.</p>
        <p className="text-sm">Go to Search to collect your first word!</p>
      </div>
    );
  }

  return (
    <div className="w-full max-w-5xl mx-auto px-4 pb-20">
      {/* Search Bar & Filters */}
      <div className="mb-8 relative max-w-md mx-auto flex gap-4">
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
             <svg className="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
               <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
             </svg>
          </div>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Filter your collection..."
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm shadow-sm"
          />
        </div>
        
        <button
          onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
          className={`px-4 py-2 rounded-lg flex items-center gap-2 border transition-colors shadow-sm ${
            showFavoritesOnly 
              ? 'bg-yellow-100 border-yellow-300 text-yellow-800' 
              : 'bg-white border-gray-300 text-gray-600 hover:bg-gray-50'
          }`}
          title="Show Favorites Only"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${showFavoritesOnly ? 'fill-current' : 'fill-none stroke-current'}`} viewBox="0 0 24 24" strokeWidth={showFavoritesOnly ? 0 : 2} stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
          </svg>
          <span className="hidden sm:inline font-medium text-sm">Favorites</span>
        </button>
      </div>

      {/* Grid */}
      {displayedCards.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayedCards.map(card => (
            <div key={card.id} className="transform transition hover:scale-[1.02]">
              <FlipCard 
                data={card} 
                isSaved={true} 
                onToggleFavorite={onToggleFavorite} 
              />
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center text-gray-400 mt-12">
          {showFavoritesOnly ? (
            <p>No favorites found. Star some cards to see them here!</p>
          ) : (
             <p>No matches found for "{searchTerm}"</p>
          )}
        </div>
      )}
    </div>
  );
};