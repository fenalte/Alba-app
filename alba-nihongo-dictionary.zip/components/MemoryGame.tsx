import React, { useState, useEffect } from 'react';
import { SavedCard } from '../types';

interface MemoryGameProps {
  collection: SavedCard[];
}

interface GameCard {
  uniqueId: string; // Unique ID for this specific card instance
  originalId: string; // ID of the vocabulary word (to check matches)
  content: string;
  type: 'kanji' | 'english';
  isFlipped: boolean;
  isMatched: boolean;
}

export const MemoryGame: React.FC<MemoryGameProps> = ({ collection }) => {
  const [cards, setCards] = useState<GameCard[]>([]);
  const [flippedCards, setFlippedCards] = useState<GameCard[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [moves, setMoves] = useState(0);
  const [gameWon, setGameWon] = useState(false);

  // Initialize Game
  const initializeGame = () => {
    if (collection.length < 8) return;

    // 1. Shuffle collection and pick first 8 words
    const shuffledCollection = [...collection].sort(() => 0.5 - Math.random());
    const selectedWords = shuffledCollection.slice(0, 8);

    // 2. Create pairs (Kanji + English)
    let gameDeck: GameCard[] = [];
    selectedWords.forEach((word) => {
      // Card 1: Kanji
      gameDeck.push({
        uniqueId: `${word.id}-kanji`,
        originalId: word.id,
        content: word.kanji,
        type: 'kanji',
        isFlipped: false,
        isMatched: false,
      });
      // Card 2: English
      gameDeck.push({
        uniqueId: `${word.id}-english`,
        originalId: word.id,
        content: word.english[0],
        type: 'english',
        isFlipped: false,
        isMatched: false,
      });
    });

    // 3. Shuffle the deck
    gameDeck = gameDeck.sort(() => 0.5 - Math.random());

    setCards(gameDeck);
    setFlippedCards([]);
    setMoves(0);
    setGameWon(false);
    setIsProcessing(false);
  };

  useEffect(() => {
    initializeGame();
  }, [collection]); // Re-init if collection loads, though usually manual restart is better

  const handleCardClick = (clickedCard: GameCard) => {
    // Ignore if already flipped, matched, or system is processing a mismatch
    if (clickedCard.isFlipped || clickedCard.isMatched || isProcessing) return;

    // Flip the card
    const newCards = cards.map(c => 
      c.uniqueId === clickedCard.uniqueId ? { ...c, isFlipped: true } : c
    );
    setCards(newCards);

    const newFlipped = [...flippedCards, clickedCard];
    setFlippedCards(newFlipped);

    // If 2 cards are flipped, check for match
    if (newFlipped.length === 2) {
      setMoves(m => m + 1);
      checkForMatch(newFlipped, newCards);
    }
  };

  const checkForMatch = (currentFlipped: GameCard[], currentCards: GameCard[]) => {
    setIsProcessing(true);
    const [card1, card2] = currentFlipped;

    const isMatch = card1.originalId === card2.originalId;

    if (isMatch) {
      // Mark as matched
      const matchedCards = currentCards.map(c => 
        c.originalId === card1.originalId ? { ...c, isMatched: true, isFlipped: true } : c
      );
      setCards(matchedCards);
      setFlippedCards([]);
      setIsProcessing(false);

      // Check win condition
      if (matchedCards.every(c => c.isMatched)) {
        setGameWon(true);
      }
    } else {
      // No match - wait then flip back
      setTimeout(() => {
        const resetCards = currentCards.map(c => 
          (c.uniqueId === card1.uniqueId || c.uniqueId === card2.uniqueId) 
            ? { ...c, isFlipped: false } 
            : c
        );
        setCards(resetCards);
        setFlippedCards([]);
        setIsProcessing(false);
      }, 1000);
    }
  };

  if (collection.length < 8) {
    return (
      <div className="flex flex-col items-center justify-center h-96 text-center px-4">
        <div className="bg-white p-8 rounded-2xl shadow-xl max-w-md">
          <div className="text-5xl mb-4">📭</div>
          <h2 className="text-2xl font-bold text-indigo-900 mb-2">Not Enough Cards</h2>
          <p className="text-gray-600 mb-6">
            You need at least 8 words in your collection to play the Memory Game. 
            Currently you have {collection.length}.
          </p>
          <p className="text-indigo-600 font-medium">Go collect more words!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-6xl mx-auto px-4 py-6 flex flex-col items-center">
      
      {/* Game Header */}
      <div className="flex justify-between items-center w-full mb-6 max-w-4xl">
        <div>
          <h2 className="text-3xl font-bold text-indigo-900">Memory Match</h2>
          <p className="text-gray-500 text-base">Find the Kanji and English pairs</p>
        </div>
        <div className="flex items-center gap-6">
          <div className="bg-indigo-50 px-5 py-3 rounded-xl shadow-sm">
            <span className="text-indigo-900 font-bold text-xl">{moves}</span>
            <span className="text-indigo-400 text-sm ml-2 uppercase font-semibold">Moves</span>
          </div>
          <button 
            onClick={initializeGame}
            className="p-3 text-indigo-600 hover:bg-indigo-50 rounded-full transition-colors"
            title="Restart Game"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-4 gap-4 sm:gap-6 w-full max-w-4xl aspect-square">
        {cards.map((card) => (
          <div 
            key={card.uniqueId}
            onClick={() => handleCardClick(card)}
            className={`
              relative cursor-pointer transition-all duration-300 transform perspective-1000
              ${card.isMatched ? 'opacity-50 cursor-default' : 'hover:scale-[1.03] hover:shadow-xl'}
            `}
          >
            <div className={`
              w-full h-full min-h-[100px] sm:min-h-[150px] rounded-2xl shadow-lg flex items-center justify-center p-4 text-center transition-all duration-500 transform-style-3d
              ${card.isFlipped ? 'rotate-y-180' : ''}
            `}>
              
              {/* Back of card (Face Down) */}
              <div className={`
                absolute inset-0 backface-hidden bg-indigo-900 rounded-2xl flex items-center justify-center
                border-4 border-indigo-800
              `}>
                <span className="text-5xl">🇯🇵</span>
              </div>

              {/* Front of card (Face Up) */}
              <div className={`
                absolute inset-0 backface-hidden rotate-y-180 rounded-2xl flex items-center justify-center p-2
                ${card.type === 'kanji' ? 'bg-paper-white font-jp text-4xl sm:text-5xl font-bold text-indigo-900' : 'bg-indigo-50 text-lg sm:text-xl font-bold text-indigo-800 leading-tight'}
                border-4 ${card.isMatched ? 'border-green-400 bg-green-50' : 'border-indigo-100'}
              `}>
                 {card.content}
              </div>

            </div>
          </div>
        ))}
      </div>

      {/* Win Modal */}
      {gameWon && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-3xl p-10 max-w-md w-full text-center shadow-2xl animate-float border-4 border-white">
            <div className="text-7xl mb-6">🎉</div>
            <h2 className="text-4xl font-extrabold text-indigo-900 mb-2">Omedetou!</h2>
            <p className="text-gray-600 mb-8 text-lg">You cleared the board in {moves} moves.</p>
            <button 
              onClick={initializeGame}
              className="w-full bg-japan-red hover:bg-red-700 text-white font-bold py-4 px-8 rounded-full shadow-lg transition-transform hover:scale-105 text-lg"
            >
              Play Again
            </button>
          </div>
        </div>
      )}

    </div>
  );
};