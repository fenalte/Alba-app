import { GoogleGenAI, Type, Modality } from "@google/genai";
import { VocabularyData } from "../types";

const TTS_VOICE_NAME = 'Kore';

// --- TTS Service ---

export const fetchTextToSpeech = async (text: string): Promise<string | undefined> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: TTS_VOICE_NAME },
          },
        },
      },
    });

    // Return the base64 string directly
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  } catch (error) {
    console.error("TTS generation failed:", error);
    return undefined;
  }
};

// --- Main Dictionary Service ---

export const fetchWordDefinition = async (query: string): Promise<VocabularyData | null> => {
  if (!process.env.API_KEY) {
    console.error("API_KEY is missing");
    throw new Error("API Key is missing. Please select a key.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Provide a Japanese dictionary entry for the word or phrase: "${query}".
      
      1. Basic Info: Kanji, Kana, Romaji, and English meanings.
      2. Sentences: Provide 2 simple general example sentences.
      3. Conjugation Check: 
         - If the word is a VERB or an I-ADJECTIVE (words that conjugate), you MUST provide the 'tenses' object with three distinct example sentences:
           a) Present: The standard non-past form.
           b) Past: The past tense form (Ta-form/Did X).
           c) Future: A context implying future intention (e.g., using 'tomorrow' or 'intent' form).
         - If the word is a NOUN or NA-ADJECTIVE (words that don't typically conjugate tense by themselves), return 'null' for the 'tenses' field.

      IMPORTANT: In ALL 'japanese' fields, wrap the occurrence of the target word (or its conjugated form) strictly with <b> and </b> tags so it can be highlighted.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            kanji: { type: Type.STRING, description: "The word in Kanji (or Kana if usually written in Kana)" },
            kana: { type: Type.STRING, description: "The reading in Hiragana/Katakana" },
            romaji: { type: Type.STRING, description: "The reading in Romaji" },
            english: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "List of English meanings (max 3)"
            },
            sentences: {
              type: Type.ARRAY,
              description: "Two general example sentences",
              items: {
                type: Type.OBJECT,
                properties: {
                  japanese: { type: Type.STRING, description: "Sentence in Japanese. Wrap target word in <b> tags." },
                  english: { type: Type.STRING, description: "English translation" },
                  romaji: { type: Type.STRING, description: "Romaji reading" }
                }
              }
            },
            tenses: {
              type: Type.OBJECT,
              description: "Only for Verbs/Adjectives. Null for Nouns.",
              nullable: true,
              properties: {
                present: {
                  type: Type.OBJECT,
                  properties: {
                    japanese: { type: Type.STRING },
                    english: { type: Type.STRING },
                    romaji: { type: Type.STRING }
                  }
                },
                past: {
                  type: Type.OBJECT,
                  properties: {
                    japanese: { type: Type.STRING },
                    english: { type: Type.STRING },
                    romaji: { type: Type.STRING }
                  }
                },
                future: {
                  type: Type.OBJECT,
                  properties: {
                    japanese: { type: Type.STRING },
                    english: { type: Type.STRING },
                    romaji: { type: Type.STRING }
                  }
                }
              },
              required: ["present", "past", "future"]
            }
          },
          required: ["kanji", "kana", "romaji", "english", "sentences"]
        }
      }
    });

    const text = response.text;
    if (!text) return null;

    // Sanitize and parse JSON
    const cleanText = text.replace(/```json|```/g, '').trim();
    const data = JSON.parse(cleanText) as VocabularyData;

    // --- Preload Audio for Sentences ---
    // We strip HTML tags before sending to TTS
    const cleanForTTS = (str: string) => str.replace(/<[^>]*>/g, '');
    
    // Helper to fetch and assign audio
    const fetchAndAssignAudio = async (obj: { japanese: string, audio?: string }) => {
        const audioData = await fetchTextToSpeech(cleanForTTS(obj.japanese));
        if (audioData) {
            obj.audio = audioData;
        }
    };

    const audioPromises: Promise<void>[] = [];

    // 1. General Sentences
    if (data.sentences) {
        data.sentences.forEach(s => {
            audioPromises.push(fetchAndAssignAudio(s));
        });
    }

    // 2. Tenses Sentences
    if (data.tenses) {
        if (data.tenses.present) audioPromises.push(fetchAndAssignAudio(data.tenses.present));
        if (data.tenses.past) audioPromises.push(fetchAndAssignAudio(data.tenses.past));
        if (data.tenses.future) audioPromises.push(fetchAndAssignAudio(data.tenses.future));
    }

    // Wait for all audio requests to complete (in parallel)
    // We use Promise.all because fetchTextToSpeech handles errors internally by returning undefined
    await Promise.all(audioPromises);

    return data;

  } catch (error) {
    console.error("Dictionary fetch failed:", error);
    throw error;
  }
};